import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCard, MatCardActions } from '@angular/material/card';
import { MatOption } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { ProductService } from '../../product.service';
import { UserdataService } from '../../service/userdata.service';
import { Product } from '../../type/Product';

@Component({
  selector: 'app-add-products',
  standalone: true,
  imports: [FormsModule,MatInputModule,MatCardActions,RouterLink,CommonModule,MatCard,MatOption],
  templateUrl:'./add-products.component.html',
  styleUrl: './add-products.component.scss'
})
export class AddProductsComponent {
userdata=inject(UserdataService)
RemovecartItem() {
throw new Error('Method not implemented.');
}
  //variable declaration.
  isBeforeAddedContent=true;
  isAddedContent=false;

  //binding the form with Database.
  product:Product={
    brandName: "",
    productCategory:"",
    imageUrl: "",
    currentPrice: "",
    standardPrice: "",
    discount: "",
    productName: "",
    userId:"",
    productId:"",
    // productQuntity:0
  }
  productService=inject(ProductService);
  router=inject(Router);
  userdetails:any
  addProduct(){
      // console.log("done ",this.product);
      // this.productService.addProduct(this.product).subscribe(result=>{
      // if(result)
      // {
      //   this.isBeforeAddedContent=false;
      //   this.isAddedContent=true;
      // }
      // })
        const requiredFields = [
  this.product.brandName,
  this.product.imageUrl,
  this.product.currentPrice,
  this.product.standardPrice,
  this.product.discount,
  this.product.productName,
  this.product.productCategory
];
  // console.log(this.product.productCategory)
  // console.log(this.product.brandName)

  //getting the clientId 
  this.userdata.getUserData().subscribe(data => {
  this.userdetails = data;
});
const updatedProduct = {
  ...this.product,
  userId:this.userdetails.userId // clientId is set here
};
// console.log(this.product.clientId)
      if(requiredFields.every(field => field !== "")&& requiredFields.every(field => field != null)){
      this.productService.addProduct(updatedProduct).subscribe(result=>{
        // this.router.navigateByUrl("/");
        if(result!=null){
        this.isAddedContent=true;
        this.isBeforeAddedContent=false;
        }
      })
    }
  }

    cleanbutton(){
  this.product.productName="";
  this.product.brandName = "";
  this.product.imageUrl = "";
  this.product.currentPrice = "";
  this.product.standardPrice = "";
  this.product.discount = "";
  this.product.brandName = "";
  this.isBeforeAddedContent=true;
  this.isAddedContent=false;
  }
}
