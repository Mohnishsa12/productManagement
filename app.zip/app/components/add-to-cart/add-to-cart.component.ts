import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCard, MatCardActions } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink } from '@angular/router';
import { Product } from '../../type/Product';
import { HeaderComponent } from "../header/header.component";

@Component({
  selector: 'app-add-to-cart',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatToolbarModule, RouterLink, MatCardActions, MatIconModule, CommonModule, MatCardActions, MatCard, HeaderComponent],
  templateUrl: './add-to-cart.component.html',
  styleUrl: './add-to-cart.component.scss'
})
export class AddToCartComponent {
RemovecartItem() {
throw new Error('Method not implemented.');
}

isopenNow=false;
count:number=0
//setting cart button open and close.
isOpenPanel(){
  console.log("hii")
  this.isopenNow=true;
  //this logic for cloing and opening the cart window.
  this.count++;
  if(this.count==2)
  {
    this.isopenNow=false;
    this.count=0;
  }
  this.ngOnInit()
}
isClosePanel(){
  this.isopenNow=false;
}

//getting all the cart data in from backend.
AllcartItems:Product[]=[];

constructor(private httpClient : HttpClient){}
  ngOnInit(): void {
    this.getcartProducts();
  }
  getcartProducts(){
      this.httpClient.get("http://localhost:8080/api/allProducts").subscribe((response:any)=>{
          this.AllcartItems=response as Product [];
          console.log(response)
      })
  }

}
