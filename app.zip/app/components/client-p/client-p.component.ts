import { Component, inject } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { ProductService } from '../../product.service';
import { Product } from '../../type/Product';

@Component({
  selector: 'app-client-p',
  standalone: true,
  imports: [RouterOutlet,RouterModule],
  templateUrl: './client-p.component.html',
  styleUrl: './client-p.component.scss'
})
export class ClientPComponent {

  //ADD-Product start
   product:Product={
    id: "",
    brand: "",
    image: "",
    currentPrice: "",
    standardPrice: "",
    discount: "",
    name: ""
  }
  productService=inject(ProductService);
  router=inject(Router);
  addProduct(){
      console.log("done ",this.product);
      this.productService.addProduct(this.product).subscribe(result=>{
        this.router.navigateByUrl("/");
      })
  }
  //ADD PRODUCT end here.

}
