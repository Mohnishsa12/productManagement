import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardActions } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink } from '@angular/router';
import { AddToCartComponent } from "../add-to-cart/add-to-cart.component";
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatToolbarModule, RouterLink, MatCardActions, MatIconModule, CommonModule, AddToCartComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
// [x: string]: any;
isopenNow=false;
isOpenPanel(){
  console.log("hii")
  this.isopenNow=true;
}
isClosePanel(){
  this.isopenNow=false;
}
}
