import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [MatInputModule,MatButtonModule,FormsModule],
  templateUrl: './search.component.html',
  styleUrl: './search.component.scss'
})
export class SearchComponent {
  @Output() searchOn = new EventEmitter<String>();
  text="";
  // click event 
  onSearch(){
    // console.log("le bhai seacrh kr dia");
    this.searchOn.emit(this.text);
  }
  // change event 
  // inputChange(event:any){
  //   // console.log("input change : "+event.target.value);
  //   this.text=event.target.value;
  // }

  // keypress event (if we trying to write any in search bar then it triggers.)
  // onClick(event:any){
    // console.log("key press event "+event);
  // }
}
