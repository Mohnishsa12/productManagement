import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIcon } from '@angular/material/icon';
import { Router, RouterOutlet } from '@angular/router';
import Swal from 'sweetalert2';
import { Product } from '../../type/Product';
import { EditProductComponent } from "../edit-product/edit-product.component";
@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [MatCardModule, CommonModule, MatButtonModule, EditProductComponent,RouterOutlet,MatIcon],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.scss'
})
//removing the product from the list
export class ProductCardComponent {
  constructor(private httpclient:HttpClient, private router: Router){}
removeProduct(product: Product) {
console.log(product.productId)
//  this.httpclient.delete(`http://localhost:8080/products/${product.productId}`).subscribe((response:any)=>{
//     if(response)
//     {
//       console.log("done");
//     }
  // console.log(data);
  // });
 
    // Confirmation SweetAlert
    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you really want to delete this product?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        // Call service to delete product
        this.httpclient.delete(`http://localhost:8080/products/${product.productId}`).subscribe((response:any)=>{
        result=response;
          if(result){
            // Show success SweetAlert
            Swal.fire('Deleted!', 'The product has been deleted.', 'success');

            // Refresh page or re-fetch the product list
            this.refreshProductList();
          }
          error: (err:any) => {
            // Handle error
            Swal.fire('Error', 'There was an issue deleting the product.', 'error');
            console.error(err);
          }
        });
      }
    });
    
  }

// Refreshes the product list by temporarily navigating away and back
refreshProductList() {
    // Navigate to a temporary route and back to force a refresh
    this.router.navigateByUrl('/Client', { skipLocationChange: true }).then(() => {
        this.router.navigate(['/Client/allProducts']);
    });

    // Option 2: Alternatively, fetch products again if you have a fetchProducts() method
    // this.fetchProducts();
  }


  //varible declaration
allProductvisible=true;
editformVisible=false;

  
addToCart(data:Product) {
  //adding in the cart table.
  this.httpclient.post("http://localhost:8080/api/addProduct",data).subscribe((response:any)=>{
    if(response)
    {
      console.log("done");
    }
  // console.log(data);
  });
}
  //getting the all card details one by one. from the home component array.
  @Input() product!:Product;//it means product vairable is the type of Product. //yha data home.hmtl se aa rha hai product varibale me.
  // crating the variable that stores the id means String output. and pass to the home.hhtml
  @Output() productView = new EventEmitter<number>();

  productid:any;
  //this View function is click function which is present in productt-card button .
  EditProduct(productId:any){
    console.log(productId)
    this.productid=productId
    this.editformVisible=true;
  }

  cancleButton(){
    this.editformVisible=false;
  }
}
