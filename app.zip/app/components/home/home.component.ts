import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { ProductService } from '../../product.service';
import { Product } from '../../type/Product';
import { HeaderComponent } from "../header/header.component";
import { ProductCardComponent } from '../product-card/product-card.component';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ProductCardComponent,HeaderComponent,CommonModule,SearchComponent,RouterOutlet],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  //Product it a type of entity class, tells that which data will products array stores,
products:Product[]=[];
filteredProducts:any[] =[];
// this is the service component or method there having product details 
productService = inject(ProductService);
//injecting router
router=inject(Router);
ngOnInit(){
      // we are setting the product variable dataintp the product array.
      // this.products=this.productService.products;
      
      //calling API to get data. from db.
      this.productService.getProducts().subscribe((result)=>{
        // console.log(result);
        this.products=result as Product [];
        this.filteredProducts=this.products;   
      })     
}
onSearch(search:String){
  console.log("to be search : "+ search)
  if(search){
  this.filteredProducts=this.products.filter(x=>x.productName.toLowerCase().includes(search.toLowerCase()));
  }
  else{
    this.filteredProducts=this.products;
  }
}

onViewProduct(event:any){
  console.log("ho gya call",event);
  this.router.navigateByUrl("/product/"+event);
}
}
