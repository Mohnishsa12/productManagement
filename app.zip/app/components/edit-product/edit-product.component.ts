import { Component, inject, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardActions } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../../product.service';
@Component({
  selector: 'app-edit-product',
  standalone: true,
  imports: [FormsModule, MatInputModule, MatCardActions, RouterLink,ReactiveFormsModule],
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.scss'] // Fixed here
})
export class EditProductComponent {
  formBuilder = inject(FormBuilder);
  route=inject(Router);
  toaterService=inject(ToastrService);
  productForm:FormGroup = this.formBuilder.group({
    productName: ['',[Validators.required,Validators.minLength(5)]],
    brandName: ['',[Validators.required]],
    imageUrl: [''],
    currentPrice: [''],
    standardPrice: [''],
    discount: ['']
  });
    productService=inject(ProductService);
    activeRoute=inject(ActivatedRoute);
    @Input() productId:any;
    ngOnInit(){
      //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
      //Add 'implements OnInit' to the class.

      console.log(this.productId);
      this.productService.getProduct(this.productId).subscribe(result=>{
        this.productForm.patchValue(result);
      })
    }
  editProduct() {
    if(this.productForm.invalid)
    {
      this.toaterService.error("Please provide details")
      return
    }
  // Merge productId into the form value
  const updatedProduct = {
    ...this.productForm.value,
    productId: this.productId // Make sure productId is included
  };

  console.log("Form submitted:", updatedProduct);

  this.productService.updateProduct(updatedProduct).subscribe(result => {
    this.toaterService.success("Product updated successfully.");
    if(result)
    {
      this.refreshProductList();
    }
  });
  }
  constructor(private router:Router){}
    // Refreshes the product list by temporarily navigating away and back
      refreshProductList() {
    // Navigate to a temporary route and back to force a refresh
    this.router.navigateByUrl('/Client', { skipLocationChange: true }).then(() => {//this is the parent compoent.
        this.router.navigate(['/Client/allProducts']);// this is the child component that is related to the client parent component.
    });
    }
 }
 
