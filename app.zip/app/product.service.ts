import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Product } from './type/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  // calling api 
  httpClient=inject(HttpClient);
//  product=[
//     {
//         data .....but noe it is store in db.json fake database.
//     }
//   ];
  constructor() { }

  //creating method for getting the data via calling api.
  getProducts(){
    return this.httpClient.get("http://localhost:8080/products/getAllproducts");
  }

  getProduct(productId:number)
  {

    return this.httpClient.get("http://localhost:8080/products/"+productId);
  }

  addProduct(updatedProduct:Product)
  {
    console.log(updatedProduct.userId)
    return this.httpClient.post<Product>("http://localhost:8080/products/addproduct",updatedProduct);
  }

  updateProduct(updatedProduct:Product)
  {
    console.log(updatedProduct)
    return this.httpClient.put<Product>("http://localhost:8080/products/"+updatedProduct.productId,updatedProduct);
  }
}

