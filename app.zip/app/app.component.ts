import { Component } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ReactiveFormsModule,RouterOutlet],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'] // Fixed here
 
  
})

export class AppComponent {
  title = 'projectProduct-management';
  
}
