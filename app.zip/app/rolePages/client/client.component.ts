import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardActions, MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from "../../components/header/header.component";
import { ProductCardComponent } from "../../components/product-card/product-card.component";
import { SearchComponent } from "../../components/search/search.component";
import { OtpPageComponent } from "../../loginRegisterModule/helper/otp-page/otp-page.component";
import { AllProductComponent } from "../helper/all-product/all-product.component";
import { DashboardComponent } from "./dashboard/dashboard/dashboard.component";
import { EditProductComponent } from "./edit-product/edit-product.component";


@Component({
  selector: 'app-client',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, OtpPageComponent, MatCardModule, RouterModule, FormsModule, MatInputModule, MatCardActions, RouterLink, CommonModule, ProductCardComponent, SearchComponent, AllProductComponent, ReactiveFormsModule, EditProductComponent, DashboardComponent],
  templateUrl: './client.component.html',
  styleUrl: './client.component.scss'
})
export class ClientComponent {
  constructor(private router: Router) { }
  logout() {
    sessionStorage.clear()
    sessionStorage.removeItem
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {//this is the parent compoent.
      this.router.navigate(['/user-p-home']);// this is the child component that is related to the client parent component.
    });
  }
}