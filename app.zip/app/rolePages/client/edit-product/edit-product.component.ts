import { Component, inject, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardActions } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../../../product.service';
import { Product } from '../../../type/Product';
@Component({
  selector: 'app-edit-product1',
  standalone: true,
  imports: [FormsModule, MatInputModule, MatCardActions, RouterLink,ReactiveFormsModule],
  templateUrl: './edit-product.component.html',
  styleUrl: './edit-product.component.scss'
})
export class EditProductComponent {

  formBuilder = inject(FormBuilder);
  route=inject(Router);
  toaterService=inject(ToastrService);
  productForm:FormGroup = this.formBuilder.group({
    name: ['',[Validators.required,Validators.minLength(5)]],
    brand: ['',[Validators.required]],
    image: [''],
    currentPrice: [''],
    standardPrice: [''],
    discount: ['']
  });
  
    productService=inject(ProductService);
    activeRoute=inject(ActivatedRoute);
     productId:any;
     //getting the binding data which is passes frommthe client component;
     @Input()
  productdetail!: Product;
     
    ngOnInit(){
      //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
      //Add 'implements OnInit' to the class.
      // this.productId=this.activeRoute.snapshot.params["productId"];
      // console.log(this.productId);
      // this.productService.getProduct(this.productId).subscribe(result=>{
      //   this.productForm.patchValue(result);
      // })
      console.log("joo")
      console.log(this.productdetail.productId+" from the edit-product component.")
    }
  editProduct() {
  //   if(this.productForm.invalid)
  //   {
  //     this.toaterService.error("Please provide details")
  //     return
  //   }
  //   console.log("Form submitted",this.productForm.value);
  //   this.productService.updateProduct(this.productForm.value).subscribe(result=>{
  //       this.toaterService.success("Updated Succesfully.");
  //       this.route.navigateByUrl("/product/"+ this.productId);
  //   });

  // if (this.productForm.invalid) {
  //   this.toaterService.error("Please provide all the details");
  //   return;
  // }

  // // Merge productId into the form value
  // const updatedProduct = {
  //   ...this.productForm.value,
  //   productId: this.productId // Make sure productId is included
  // };

  // console.log("Form submitted:", updatedProduct);

  // this.productService.updateProduct(updatedProduct).subscribe(result => {
  //   this.toaterService.success("Product updated successfully.");
  //   this.route.navigateByUrl("/product/" + this.productId);
  // });
  console.log("hii");
  }
 }
 
