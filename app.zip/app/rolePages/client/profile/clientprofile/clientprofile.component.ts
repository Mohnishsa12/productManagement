import { Component } from '@angular/core';
import { UserdataService } from '../../../../service/userdata.service';
import { userData } from '../../../../type/loginData';

@Component({
  selector: 'app-clientprofile',
  standalone: true,
  imports: [],
  templateUrl: './clientprofile.component.html',
  styleUrl: './clientprofile.component.scss'
})
export class ClientprofileComponent {
     userData: userData | null = null;

  constructor(private userdata:UserdataService) {}

ngOnInit(): void {
  this.userdata.getUserData().subscribe((data: userData | null) => {
    this.userData = data;
    // console.log("User Data in ClientComponent:", this.userData); // Verify final data
  });
}
}
