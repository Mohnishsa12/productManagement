import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from '../../type/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductDataService {
 private productSource = new BehaviorSubject<Product | null>(null);
  currentProduct = this.productSource.asObservable();

  constructor() {}

  setProduct(product: Product) {
    this.productSource.next(product);
  }

  clearProduct() {
    this.productSource.next(null);
  }
}
