import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { Product } from '../../../type/Product';

@Component({
  selector: 'app-all-product',
  standalone: true,
  imports: [MatCardModule,CommonModule,MatButtonModule],
  templateUrl: './all-product.component.html',
  styleUrl: './all-product.component.scss'
})
export class AllProductComponent {
 constructor(private httpclient:HttpClient){}
// addToCart(data:Product) {
//   //adding in the cart table.
//   this.httpclient.post("http://localhost:8080/api/addProduct",data).subscribe((response:any)=>{
//     if(response)
//     {
//       console.log("done");
//     }
//   // console.log(data);
//   });
// }

  //getting the all card details one by one. from the home component array.
  @Input() product!:Product;//it means product vairable is the type of Product. //yha data home.hmtl se aa rha hai product varibale me.
  // crating the variable that stores the id means String output. and pass to the home.hhtml
  @Output() productView = new EventEmitter<String>();
  // ******agar kuch perform nhi hua to yha number kr dena

  //this View function is click function which is present in productt-card button .
  view(){
    console.log("le bhai event bhi handle ho gya");
    // setting the id and passing to the home.html
    this.productView.emit(this.product.productId);
  }

  //edit the product.
  editProduct(product:Product){
  }
}
