import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPComponent } from './user-p.component';

describe('UserPComponent', () => {
  let component: UserPComponent;
  let fixture: ComponentFixture<UserPComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
