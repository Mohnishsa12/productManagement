import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ProductService } from '../../product.service';
import { Product } from '../../type/Product';
import { UserPHomeComponent } from "../user-p-helper/user-p-home/user-p-home.component";
import { UserPNavComponent } from "../user-p-helper/user-p-nav/user-p-nav.component";

@Component({
  selector: 'app-user-p',
  standalone: true,
  imports: [ RouterModule, UserPNavComponent, UserPHomeComponent,CommonModule],
  templateUrl: './user-p.component.html',
  styleUrl: './user-p.component.scss'
})
export class UserPComponent {
  // variable declaration
  islogin=true;
  isLogout=false;
  isAddToCart=false;
    constructor(private httpclient:HttpClient){}

     //Product it a type of entity class, tells that which data will products array stores,
products:Product[]=[];
filteredProducts:any[] =[];
// this is the service component or method there having product details 
productService = inject(ProductService);
//injecting router
router=inject(Router);
// ngOnInit(){
//       // we are setting the product variable dataintp the product array.
//       // this.products=this.productService.products;
      
//       //calling API to get data. from db.
//       this.productService.getProducts().subscribe((result)=>{
//         // console.log(result);
//         this.products=result as Product [];
//         this.filteredProducts=this.products;   
//         console.log(this.filteredProducts)
//       }) 
//     // Find the anchor tag and simulate a click event
//     //by default home content is pre load .
//     const anchor = document.querySelector('a[routerLink="user-p-home"]');
//     const anchorElement = anchor as HTMLAnchorElement;
//     if (anchor) {
//       anchorElement.click();
//     } 
//        //checking the user is loggin or not.
//     let isLoggedin=sessionStorage.getItem("isLoggedin");
//     if(isLoggedin || isLoggedin === "true")
//     {
//       this.islogin=false;
//         this.isLogout=true;
//     }
 
// }

// Logout(){
//     sessionStorage.setItem("isLoggedin","false");
//     this.isLogout=false;
//     this.router.navigate(["/user-p-home"])
// }




 ngOnInit() {
    this.loadProductData();

    // Check session storage and update login state
    this.updateLoginState();

    // Navigate to home if logged in by default
    if (this.isLogout) {
      this.router.navigate(['/user-p-home']);
    }
  }

  loadProductData() {
    // Fetching products from the service
    this.productService.getProducts().subscribe((result) => {
      this.products = result as Product[];
      this.filteredProducts = this.products;
      console.log(this.filteredProducts);
    });
  }

  updateLoginState() {
    const isLoggedIn = sessionStorage.getItem("isLoggedin") === "true";
    this.islogin = !isLoggedIn;
    this.isLogout = isLoggedIn;
    this.isAddToCart=isLoggedIn;
  }
  
  viewCart(){
    console.log("cart is this...")
  }
  Logout() {
    sessionStorage.setItem("isLoggedin", "false");
    this.updateLoginState();  // Update login state after logging out
    this.router.navigate(["/user-p-home"]);
  }

}

