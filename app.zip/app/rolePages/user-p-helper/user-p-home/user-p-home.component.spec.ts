import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPHomeComponent } from './user-p-home.component';

describe('UserPHomeComponent', () => {
  let component: UserPHomeComponent;
  let fixture: ComponentFixture<UserPHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPHomeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
