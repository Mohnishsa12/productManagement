import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ProductService } from '../../../product.service';
import { UserdataService } from '../../../service/userdata.service';
import { Product } from '../../../type/Product';

@Component({
  selector: 'app-user-p-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-p-home.component.html',
  styleUrl: './user-p-home.component.scss'
})
export class UserPHomeComponent {
constructor(private httpclient:HttpClient){}

     //Product it a type of entity class, tells that which data will products array stores,
products:Product[]=[];
HomeGadgets:any[] =[];
ElectronicProducts:any[] =[];
ElectronicsGadgets:any[] =[];
// this is the service component or method there having product details 
productService = inject(ProductService);
//injecting router
router=inject(Router);
ngOnInit(){
      // we are setting the product variable dataintp the product array.
      // this.products=this.productService.products;
      
      //calling API to get data. from db.
      this.productService.getProducts().subscribe((result)=>{
        // console.log(result);
        this.products=result as Product [];
        // this.filteredProducts=this.products;   
        // console.log(this.filteredProducts)
        //filtered product by category
        this.ElectronicsGadgets = this.products.filter(product => product.productCategory === 'ElectronicGadgets');
      this.ElectronicProducts = this.products.filter(product => product.productCategory === 'ElectronicProducts');
      this.HomeGadgets = this.products.filter(product => product.productCategory === 'HomeGadgets');
      })     
}
product:Product={
    brandName: "",
    productCategory:"",
    imageUrl: "",
    currentPrice: "",
    standardPrice: "",
    discount: "",
    productName: "",
    userId:"",
    productId:"",
    // productQuntity:0
  }
userdata=inject(UserdataService)
  userdetails!: any;
  addToCart(product: Product) {

  if(sessionStorage.getItem("isLoggedin") === "true")
  {
    // Subscribe to getUserData to receive the user data
    this.userdata.getUserData().subscribe(
      (data) => {
        if (data && data.userId) {
          // Set userId in the product
          product.userId = data.userId;
          console.log('User ID:', data.userId); // Verify user ID is received


          // Send the product to the server
          this.httpclient.post<Product>("http://localhost:8080/api/addToCart", product).subscribe(
            (result) => {
              if (result) {
                Swal.fire({
                  title: 'Success!',
                  text: 'Product has been added to your cart successfully.',
                  icon: 'success',
                  confirmButtonText: 'OK'
                });
              }
            },
            (error) => {
              Swal.fire({
                title: 'Error!',
                text: 'Failed to add product to cart. Please try again.',
                icon: 'error',
                confirmButtonText: 'OK'
              });
            }
          );
        } else {
          console.log("User ID not available in user data."); // Handle case when userId is missing
        }
      },
      (error) => {
        console.error("Error retrieving user data:", error);
      }
    );
  }
  else{
    Swal.fire({
                title: 'Error!',
                text: 'Please login first...',
                icon: 'error',
                confirmButtonText: 'OK'
              });
  }
  
  }
}