import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPNavComponent } from './user-p-nav.component';

describe('UserPNavComponent', () => {
  let component: UserPNavComponent;
  let fixture: ComponentFixture<UserPNavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPNavComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
