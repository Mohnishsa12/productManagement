import { Component } from '@angular/core';

@Component({
  selector: 'app-user-p-contact',
  standalone: true,
  imports: [],
  templateUrl: './user-p-contact.component.html',
  styleUrl: './user-p-contact.component.scss'
})
export class UserPContactComponent {

}
