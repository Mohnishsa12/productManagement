import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPContactComponent } from './user-p-contact.component';

describe('UserPContactComponent', () => {
  let component: UserPContactComponent;
  let fixture: ComponentFixture<UserPContactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPContactComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
