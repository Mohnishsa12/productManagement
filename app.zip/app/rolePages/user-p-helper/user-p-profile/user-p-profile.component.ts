import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { UserdataService } from '../../../service/userdata.service';
import { orderdetails2 } from '../../../type/orderDetails2';
import { Product } from '../../../type/Product';

@Component({
  selector: 'app-user-p-profile',
  standalone: true,
  imports: [CommonModule, MatIcon, FormsModule, ReactiveFormsModule],
  templateUrl: './user-p-profile.component.html',
  styleUrl: './user-p-profile.component.scss'
})
export class UserPProfileComponent {
  //variable declaration
  isCardViewProduct = false
  isEdituserProfile = false
  //gettting the userData
  userDataService = inject(UserdataService)
  userData: any;
  userId: number = 0
  //array for storing the list of orderplace products
  orederedProducts: Product[] = []
  orderpaymentDetails: orderdetails2[] = []
  constructor(private httpclient: HttpClient) { }
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.userDataService.getUserData().subscribe((response) => {
      this.userData = response;
    })
    this.httpclient.get(`http://localhost:8080/All/users/${this.userData.userId}`).subscribe((data) => {
      this.userData = data
      // console.log(this.userData)
      this.userId = this.userData.userId
      // console.log( )
    })

    //getting the user place order Details.
    this.httpclient.get<orderdetails2[]>(`http://localhost:8080/api/orderDetails/${this.userData.userId}`).subscribe((data) => {
      if (data) {
        this.orderpaymentDetails = data as []
        // console.log("le bhai orderDetals ki id", this.orderpaymentDetails)
      }
    })

    // //getting the user place order products.
    // this.httpclient.get(`http://localhost:8080/api/orders/user/${this.userData.userId}`).subscribe((data) => {
    //   if (data) {
    //     this.orederedProducts = data as []
    //     console.log(this.orederedProducts)
    //   }
    // })
  }

  //user profile code start here
  //getting the userProfile data from the form.
  formBuilder = inject(FormBuilder);
  editForm = this.formBuilder.group({
    name: [''],
    email: [''],
    password: [''],
    userRole: ""

  });
  saveEditUser() {
    if (this.editForm.valid) {
      this.httpclient.put(`http://localhost:8080/All/update/user/${this.userData.userId}`, this.editForm.value).subscribe((response) => {
        this.isEdituserProfile = false;
        // console.log(this.editForm.value)
        // console.log("user edit")

        //again fetching the userData from userdb
        this.ngOnInit()
      })
    }
  }

  editProfile() {
    this.isEdituserProfile = true;
  }

  cancleButton() {
    this.isEdituserProfile = false;
  }
  //user profile code end here

  //getting all the products here

  //user place orders show start here
  viewOrderProducts(orderId: any) {
    this.httpclient.get<Product[]>(`http://localhost:8080/api/orders/user/${orderId}`).subscribe((response) => {
      if (response) {
        this.orederedProducts = response as []
        // console.log(this.orederedProducts)
        this.isCardViewProduct = true
      }
    })
  }
  closeproductViewCard() {
    this.isCardViewProduct = false
  }
  //user place orders show start here
}
