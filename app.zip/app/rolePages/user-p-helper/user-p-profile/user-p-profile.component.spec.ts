import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPProfileComponent } from './user-p-profile.component';

describe('UserPProfileComponent', () => {
  let component: UserPProfileComponent;
  let fixture: ComponentFixture<UserPProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
