import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPLoginComponent } from './user-p-login.component';

describe('UserPLoginComponent', () => {
  let component: UserPLoginComponent;
  let fixture: ComponentFixture<UserPLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPLoginComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
