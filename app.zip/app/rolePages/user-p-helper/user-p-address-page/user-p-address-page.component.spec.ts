import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPAddressPageComponent } from './user-p-address-page.component';

describe('UserPAddressPageComponent', () => {
  let component: UserPAddressPageComponent;
  let fixture: ComponentFixture<UserPAddressPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPAddressPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPAddressPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
