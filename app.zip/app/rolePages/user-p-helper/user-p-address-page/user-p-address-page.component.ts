import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { BillingDataServiceService } from '../../../service/billing-data-service.service';
import { UserdataService } from '../../../service/userdata.service';
import { address } from '../../../type/addressdata';
import { userData } from '../../../type/loginData';
import { orderdetails } from '../../../type/orderDetails';
import { orderdetails2 } from '../../../type/orderDetails2';
import { orderPlace } from '../../../type/orderPlace';
import { Product } from '../../../type/Product';
declare var Razorpay: any;
@Component({
  selector: 'app-user-p-address-page',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './user-p-address-page.component.html',
  styleUrl: './user-p-address-page.component.scss'
})
export class UserPAddressPageComponent {
  // variable declaration  
  countProduct!: number;
  totalPrice!: number;
  actualPrice!: number;
  totalAmount!: number;
  totalProduct!: number;
  randomAddress?: address
  //getting all the adress in this array
  AlladdressOfUser?: address
  //paymntkey
  paymentkey: any
  //cart products
  cartProducts: orderPlace[] = []
  //orderDetailsid
  orderDetailsId: any

  billingdata = inject(BillingDataServiceService)
  userdataservice = inject(UserdataService);

  userdata?: userData;

  //getting the userData.
  data: any;
  ngOnInit() {
    this.data = this.billingdata.getData();
    this.countProduct = this.data.countProduct;
    this.totalPrice = this.data.totalPrice;
    this.actualPrice = this.data.actualPrice;
    this.totalAmount = this.data.totalAmount;
    this.totalProduct = this.data.totalProduct;

  }
  // //getting the user Address
  //   address:address = {
  //   name: '',
  //   mobileNumber: '',
  //   pincode: '',
  //   locality: '',
  //   address: '',
  //   city: '',
  //   state: '',
  //   landmark: '',
  //   alternatePhone: '',
  //   addressType: '',
  //   userId:''
  // };

  // formBuilder = inject(FormBuilder);
  route = inject(Router);
  productForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private httpclient: HttpClient) {
    this.productForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(5)]],
      number: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      pincode: ['', Validators.required],
      locality: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      landmark: [''],
      alternatePhone: ['', Validators.pattern(/^\d{10}$/)],
      addressType: ['home', Validators.required]
    });
  }
  //variable declaration
  addressData?: address
  userId: any
  submit() {
    if (this.productForm.valid) {
      //getting the userData
      this.userdataservice.getUserData().subscribe((data => {
        if (data && data.userId) {
          this.userdata = data
          // console.log(this.userdata)
        }
        else {
          console.log("userdata is not transfer")
        }
      }))
      this.userId = this.userdata?.userId

      // setting the address data in the address object.
      this.addressData = {
        name: this.productForm.get('name')?.value,
        number: this.productForm.get('number')?.value,
        pincode: this.productForm.get('pincode')?.value,
        locality: this.productForm.get('locality')?.value,
        address: this.productForm.get('address')?.value,
        city: this.productForm.get('city')?.value,
        state: this.productForm.get('state')?.value,
        landmark: this.productForm.get('landmark')?.value,
        alternatePhone: this.productForm.get('alternatePhone')?.value,
        addressType: this.productForm.get('addressType')?.value,
        userId: this.userId
      };

      this.payNow()
    }
    else {
      Swal.fire({
        title: 'Error!',
        text: 'please fill up the Data',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  }
  //having order details 
  orderDetails?: orderdetails
  //setting the addressid

  //razorpay payment operation
  payNow() {
    const razorpayOptions = {
      key: 'rzp_test_htTDeYrnLVgrHP',  // Your Razorpay API key
      amount: this.data.totalAmount * 100,  // Amount in paise (INR)
      currency: 'INR',
      name: this.userdata?.name,
      description: 'Razorpay Payment',
      image: '',  // Add your logo if needed
      prefill: {
        name: this.userdata?.name,
        email: this.userdata?.email,
        // contact: this.userdata?.phone  // Ensure phone number is available if needed
      },
      theme: {
        color: '#6466e3'  // Your desired color
      },
      modal: {
        ondismiss: () => {
          // console.log('Payment modal dismissed');
          // giving the sweet alert when payment failure 
          Swal.fire({
            title: 'Error!',
            text: 'payment cancle',
            icon: 'error',
            confirmButtonText: 'retry',
            confirmButtonColor: '#3085d6',  // Custom button color (optional)
            background: '#f8f9fa',  // Custom background color (optional)
            timer: 3000,  // Optional timer to auto-close the alert after 3 seconds
          });
        }
      },
      handler: (response: any) => {

        // setting paymentkey 
        this.paymentkey = response.razorpay_payment_id

        //calling the address saving method
        this.saveAddressDb()

        // Handle the form data or perform actions after successful payment
        this.productForm.value;  // Example form value logging
      },
      error: (error: any) => {
        // Failure callback when payment fails
        console.error('Payment failed:', error);

      }
    };

    const rzp = new Razorpay(razorpayOptions);
    rzp.open();
  }


  saveAddressDb() {
    // If payment is successful, post the address to the DB
    this.httpclient.post("http://localhost:8080/api/add/address", this.addressData).subscribe(
      (responce) => {
        // console.log('Response from address API:', responce);

        // Assuming the response is an array, cast it to an array
        this.AlladdressOfUser = responce as address;
        // console.log('All Address of User:', this.AlladdressOfUser);
        // If addresses exist, pick a random one
        // const addressId: any = this.randomAddress?.id
        const addressId: any = this.AlladdressOfUser.id
        // Prepare order details
        this.orderDetails = {
          paymentType: "online",
          paymentKey: this.paymentkey,
          totalPayment: this.data.totalAmount,
          addressId: addressId, // Use random address's ID
          userId: this.userId
        };

        // console.log('Order Details:', this.orderDetails);

        // Now calling the order API
        this.httpclient.post<orderdetails2>("http://localhost:8080/api/addorder", this.orderDetails).subscribe(
          (response) => {
            // console.log('Response from addorder API:', response);
            // console.log("order details id is : ", response)
            this.orderDetailsId = response.orderId;
            this.httpclient.get<Product[]>(`http://localhost:8080/api/allProducts/${this.userId}`).subscribe((result) => {
              // if (result) {
              this.cartProducts = result as orderPlace[];
              // console.log(this.cartProducts)
              // Add the orderDetailsId to each product
              this.cartProducts.forEach((product) => {
                // console.log(this.orderDetailsId)
                product.orderDetailsId = this.orderDetailsId;
              });
              // }
              //adding product in orderPlace table start here
              // console.log("after updating oorderdetails id  : ", this.cartProducts);
              // this.countProduct = this.cartProducts.length
              this.httpclient.post("http://localhost:8080/api/orders/user", this.cartProducts, { responseType: 'text' }).subscribe((response) => {
                if (response == "done") {
                  Swal.fire({
                    title: 'Done',
                    text: 'Your order has been successfully placed.',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#f8f9fa',
                    timer: 3000
                  });
                  this.route.navigate(["/user-p-home"]);
                }
                else {
                  Swal.fire({
                    title: 'Error',
                    text: 'Try again leter.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#f8f9fa',
                    timer: 3000
                  });
                  this.route.navigate(["/user-p-home"]);
                }
              })
            });
          });
      }
    )
  }
};

