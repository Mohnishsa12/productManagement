import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPAddTocartComponent } from './user-p-add-tocart.component';

describe('UserPAddTocartComponent', () => {
  let component: UserPAddTocartComponent;
  let fixture: ComponentFixture<UserPAddTocartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPAddTocartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPAddTocartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
