import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import Swal from 'sweetalert2';
import { BillingDataServiceService } from '../../../service/billing-data-service.service';
import { UserdataService } from '../../../service/userdata.service';
import { Product } from '../../../type/Product';

@Component({
  selector: 'app-user-p-add-tocart',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './user-p-add-tocart.component.html',
  styleUrl: './user-p-add-tocart.component.scss'
})
export class UserPAddTocartComponent {
  // variable declaration 
  products: Product[] = [];
  productDetails?: Product
  constructor(private httpclient: HttpClient, private router: Router, private billingdata: BillingDataServiceService) { }
  // getting userData
  userdetails = inject(UserdataService);
  userData: any;
  //getting all the product count present in cart data base.
  countProduct: number = 0
  //current price
  totalPrice: number = 0
  //standard price 
  actualPrice: number = 0
  //total amount
  totalAmount: number = 0
  //number of product order counter
  totalProduct: number = 1

  ngOnInit(): void {
    // Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    // Add 'implements OnInit' to the class.
    this.userdetails.getUserData().subscribe((data) => {
      if (data && data.userId) {
        this.userData = data;
        // console.log(this.userData.userId);

        // getting cart products after user data is retrieved
        this.httpclient.get<Product[]>(`http://localhost:8080/api/allProducts/${this.userData.userId}`).subscribe((result) => {
          this.products = result as Product[];
          // console.log(this.products);
          this.countProduct = this.products.length
          //calling billing counter
          this.billingCounter()

        });
      }
    });
  }

  removeProduct(productId: any) {
    console.log(productId)
    this.httpclient.delete(`http://localhost:8080/api/delete/${productId}`).subscribe((result) => {
      if (result) {
        Swal.fire({
          title: 'Success!',
          text: 'Product removed',
          icon: 'success',
          confirmButtonText: 'OK'
        }).then(() => {
          // Update the products list by removing the deleted product
          this.products = this.products.filter(product => product.productId !== productId);
          //calling billing counter after removing theproduct for recalculating the bill
          this.billingCounter()
        });
      } else {
        Swal.fire({
          title: 'Error!',
          text: 'Failed to remove',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    });
  }

  billingCounter() {
    // Calculate the current price by summing the currentPrice of all products
    this.totalPrice = this.products.reduce((accumulator, product) => {
      return accumulator + Number(product.currentPrice); // Convert currentPrice to number
    }, 0);
    // console.log(this.totalPrice)

    // Calculate the standard price by summing the currentPrice of all products
    this.actualPrice = this.products.reduce((accumulator, product) => {
      return accumulator + Number(product.standardPrice); // Convert currentPrice to number
    }, 0);
    // this.actualPrice = this.totalPrice * 0.1; // Calculate discount (example: 10%)
    // console.log(this.actualPrice)
    this.totalAmount = this.actualPrice - this.totalPrice
    this.totalAmount = this.totalPrice + 59;  // Add packaging fee
  }
  // // Method to increase quantity for a specific product
  // increaseQuantity(index: number): void {
  //   if (this.products[index]) {  // Check if the product exists at the specified index
  //     this.products[index].productQuntity += 1;
  //     // this.calculateTotalPrice();  // Recalculate total price after quantity change
  //   }
  // }

  // // Method to decrease quantity for a specific product
  // decreaseQuantity(index: number): void {
  //   if (this.products[index] && this.products[index].productQuntity > 1) {  // Ensure the product exists and quantity is greater than 1
  //     this.products[index].productQuntity -= 1;
  //     // this.calculateTotalPrice();  // Recalculate total price after quantity change
  //   }
  // }
  billingPage: boolean = true;

  navigateToBilling() {
    if (this.products.length > 0) {
      this.router.navigate(['user-p-addtocart/user-p-addresspage']);
      this.billingPage = false
      this.billingdata.setData(this.countProduct, this.totalPrice, this.actualPrice, this.totalAmount, this.totalProduct);
    }
    else {
      Swal.fire({
        title: 'Add product FIRST!',
        text: 'empty cart',
        icon: 'error',
        confirmButtonText: 'OK'
      })
    }
  }
}
