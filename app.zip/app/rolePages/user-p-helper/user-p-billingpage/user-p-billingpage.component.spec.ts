import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPBillingpageComponent } from './user-p-billingpage.component';

describe('UserPBillingpageComponent', () => {
  let component: UserPBillingpageComponent;
  let fixture: ComponentFixture<UserPBillingpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPBillingpageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPBillingpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
