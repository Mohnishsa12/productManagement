import { Component } from '@angular/core';
import { BillingDataServiceService } from '../../../service/billing-data-service.service';

@Component({
  selector: 'app-user-p-billingpage',
  standalone: true,
  imports: [],
  templateUrl: './user-p-billingpage.component.html',
  styleUrl: './user-p-billingpage.component.scss'
})
export class UserPBillingpageComponent {
  

}
