import { Component } from '@angular/core';

@Component({
  selector: 'app-user-p-register',
  standalone: true,
  imports: [],
  templateUrl: './user-p-register.component.html',
  styleUrl: './user-p-register.component.scss'
})
export class UserPRegisterComponent {

}
