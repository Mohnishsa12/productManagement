import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPRegisterComponent } from './user-p-register.component';

describe('UserPRegisterComponent', () => {
  let component: UserPRegisterComponent;
  let fixture: ComponentFixture<UserPRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPRegisterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserPRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
