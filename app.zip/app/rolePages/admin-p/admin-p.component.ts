import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { UserdataService } from '../../service/userdata.service';
import { userData } from '../../type/loginData';
@Component({
  selector: 'app-admin-p',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIcon, FormsModule, ReactiveFormsModule],
  templateUrl: './admin-p.component.html',
  styleUrl: './admin-p.component.scss'
})
export class AdminPComponent {

  //variable declaration.
  userData: userData | null = null;
  userCount: any
  productCount: any
  dashboard: boolean = true
  userdetails: boolean = false;
  Adduserform: boolean = false;
  editform = false;
  Users: userData[] = [];
  filteredUsers: any[] = [];
  text = ""
  constructor(private userdata: UserdataService, private httpclint: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.userdata.getUserData().subscribe((data: userData | null) => {
      this.userData = data;

      //getting the usercount
      this.httpclint.get("http://localhost:8080/user/count").subscribe((responce) => {
        this.userCount = responce
        console.log(this.userCount)
      })
      //getting the product count
      this.httpclint.get("http://localhost:8080/user/products/count").subscribe((responce) => {
        this.productCount = responce
        console.log(this.productCount)
      })
      //getting all the users from the DB.
      this.httpclint.get("http://localhost:8080/All/users").subscribe((response) => {
        this.Users = response as userData[];
        this.filteredUsers = this.Users;
        console.log(this.filteredUsers)
      })
      // console.log("User Data in ClientComponent:", this.userData); // Verify final data
    });
  }

  onSearch() {
    // console.log("to be search : "+ this.text)
    if (this.text) {
      this.filteredUsers = this.Users.filter(x => x.name.toLowerCase().includes(this.text.toLowerCase()));
    }
    else {
      this.filteredUsers = this.Users;
    }
    console.log("After search:", JSON.stringify(this.filteredUsers, null, 2));
  }

  customerpage() {
    this.userdetails = true;
    this.dashboard = false;
  }

  Alldata() {
    this.userdetails = false;
    this.dashboard = true;
  }

  logout() {
    sessionStorage.clear()
    sessionStorage.removeItem
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {//this is the parent compoent.
      this.router.navigate(['/user-p-home']);// this is the child component that is related to the client parent component.
    });
  }


  //getting the userdata when clicks on the edit button
  userDetails: any;
  onEdit(userdata: any) {
    console.log(userdata)
    this.userDetails = userdata;
    this.editform = true;
  }

  cancleButton() {
    this.editform = false;
    this.Adduserform = false
  }

  formBuilder = inject(FormBuilder);
  userfrom = this.formBuilder.group({
    name: ['', [Validators.required, Validators.minLength(5)]],
    email: ['', [Validators.required]],
    password: [''],
    userRole: [''],
    userId: ['']
  });
  //editing the user credentials by the ADMIN page.
  SaveData() {
    if (this.userfrom.valid) {
      console.log(this.userfrom.value)
    }
    this.httpclint.put("http://localhost:8080/All/update/user/" + this.userDetails.userId, this.userfrom.value).subscribe((result) => {
      this.editform = false;
      if (result) {
        this.refreshProductList();
      }
    })

  }
  // Refreshes the product list by temporarily navigating away and back
  refreshProductList() {
    this.editform = false;
    // Navigate to a temporary route and back to force a refresh
    this.router.navigateByUrl('/admin', { skipLocationChange: true }).then(() => {//this is the parent compoent.
      this.router.navigate(['/admin']);// this is the child component that is related to the client parent component.
    });
  }

  onDelete(userId: any) {
    console.log(userId);
    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you really want to delete this User?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        this.httpclint.delete(`http://localhost:8080/All/delete/user/${userId}`).subscribe({
          next: (response: any) => {
            if (response) {
              Swal.fire('Deleted!', 'The User has been deleted.', 'success');

              this.refreshUserlist();
            }
          },
          error: (err: any) => {
            Swal.fire('Error', 'There was an issue deleting the User.', 'error');
            console.error(err);
          }
        });
      }
    });
  }

  // Refreshes the user list by temporarily navigating away and back
  refreshUserlist() {
    // Navigate to a temporary route and back to force a refresh
    this.router.navigateByUrl('/admin', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/admin']);
    });
  }

  //Function for Adding the new user in db by ADMIN
  userfrom1 = this.formBuilder.group({
    name: ['', [Validators.required, Validators.minLength(5)]],
    email: ['', [Validators.required]],
    password: [''],
    userRole: [''],
  });
  
  SaveUser() {
    console.log(this.userfrom1.value)
    if (this.userfrom1.valid) {
      this.httpclint.post("http://localhost:8080/All/AddUser", this.userfrom1.value).subscribe((result) => {
        if (result) {
          Swal.fire('Added!', 'The User has been Added.', 'success');
          this.refreshUserlist()
        }
      })
    }
  }
}
