import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TestingComponent } from "../../components/testing/testing/testing.component";

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, TestingComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

public data = new FormGroup({
    userId: new FormControl(''),
    password: new FormControl('')
  });

  constructor(private httpClient: HttpClient, private router: Router) {} // Inject Router

  public handleSubmitLoginData() {
    console.log(this.data.value);

    this.httpClient.post('http://localhost:8080/Loginuser', this.data.value).subscribe({
      next: (response: any) => {
        if (response) {
          // Routing to the welcome page after successful login.
          this.router.navigate(['/verification']);
          alert("otp sended.");
        } else {
          alert("Wrong info");
        }
      },
      error: (err: HttpErrorResponse) => { // Explicitly typing the error parameter
        // Handle server error
        console.error('Error occurred:', err);
        alert("Login failed. Please check your credentials.");
      }
    });
  }

//routing for creating new account
  registerPgRouting() {
    this.router.navigate(['/register']);
}
}

