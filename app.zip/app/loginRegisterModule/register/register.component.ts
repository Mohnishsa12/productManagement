import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {

 
    public registrationForm = new FormGroup ({
        name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
    })
    constructor(private httpClient : HttpClient, private router : Router){}

  onSubmit(){
      console.log(this.registrationForm.value)
      this.httpClient.post('http://localhost:8080/Adduser', this.registrationForm.value).subscribe(response =>{
        if(response)
        {
          this.router.navigate(["/login"])
          alert("Successfully registered")
        }
        else{
          alert("not registered");
        }
      })
  }
}

