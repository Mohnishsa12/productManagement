import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserdataService } from '../../../service/userdata.service';
import { userData } from '../../../type/loginData';

@Component({
  selector: 'app-otp-page',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './otp-page.component.html',
  styleUrl: './otp-page.component.scss'
})
export class OtpPageComponent {

  //binding the input field data with it.
  public otpVerifing = new FormGroup({
      otpNumber : new FormControl('')
  });

  //constructer for creating the object if httpClient for calling the apis.
  constructor (private httpClient : HttpClient, private router : Router,private userdataservice : UserdataService){}

  userData!: userData;
  otpVerify() {
    // const otp = this.otpVerifing.value;
    console.log(this.otpVerifing.value);  // Check if OTP value is being printed correctly
    this.httpClient.post('http://localhost:8080/verifyOtp', this.otpVerifing.value, { responseType: 'json' })
        .subscribe((response: any) => {
        this.userData=response;
        if(this.userData!=null)
        {
            // console.log(this.userData);
            // console.log(this.userData.userRole)

            this.userdataservice.setUserData(this.userData);
            
              this.router.navigate(["/"+this.userData.userRole])
            console.log("otp ok")
            //auth guarding
            sessionStorage.setItem("isLoggedin","true");
            // console.log(response)
            }
            else{
              sessionStorage.setItem("isLoggedin","false");
            }
        }, (error: any) => {
            console.error("Error during OTP verification: ", error);
        });
}

}

