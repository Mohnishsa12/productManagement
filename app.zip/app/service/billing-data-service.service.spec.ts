import { TestBed } from '@angular/core/testing';

import { BillingDataServiceService } from './billing-data-service.service';

describe('BillingDataServiceService', () => {
  let service: BillingDataServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BillingDataServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
