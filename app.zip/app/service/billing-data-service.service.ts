import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BillingDataServiceService {

 countProduct = 0;
  totalPrice = 0;
  actualPrice = 0;
  totalAmount = 0;
  totalProduct=0;

  // Method to set values
  setData(countProduct: number, totalPrice: number, actualPrice: number, totalAmount: number,totalProduct:number) {
    this.countProduct = countProduct;
    this.totalPrice = totalPrice;
    this.actualPrice = actualPrice;
    this.totalAmount = totalAmount;
    this.totalProduct=totalProduct;
  }

  // Method to get all values
  getData() {
    return {
      countProduct: this.countProduct,
      totalPrice: this.totalPrice,
      actualPrice: this.actualPrice,
      totalAmount: this.totalAmount,
      totalProduct:this.totalProduct
    };
  }
}
