import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { userData } from '../type/loginData';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {
// When UserdataService is first created, check if there’s userData in sessionStorage and set it as the initial value for the BehaviorSubject.
  private userData = new BehaviorSubject<userData | null>(
  JSON.parse(sessionStorage.getItem('userData') || 'null') // Retrieve from sessionStorage if available
);

  // Method to set userData
  setUserData(data: userData) {
    // console.log("Setting userData in service:", data);
    this.userData.next(data);
    sessionStorage.setItem('userData', JSON.stringify(data)); // Store data in sessionStorage
  }

  // Method to get userData as an observable
getUserData(): Observable<userData | null> {
  // console.log("Getting userData from service:", this.userData.value); // Check current value
  return this.userData.asObservable();
}
}
