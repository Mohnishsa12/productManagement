import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  //ye ek functional interface hai to hum constructer nhi bna skte isliye humne inject krke Router ki object bnaya hai routing ke liye.
  const _router=inject(Router);
  let isLoggedin=sessionStorage.getItem("isLoggedin");
  if(!isLoggedin || isLoggedin === "false")
  {
    _router.navigate(['/']);
    return false;
  }
  return true;
};
