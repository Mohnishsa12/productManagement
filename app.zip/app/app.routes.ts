import { Routes } from '@angular/router';
import { authGuard } from './authGuard/auth.guard';
import { AddProductsComponent } from './components/add-products/add-products.component';
// import { EditProductComponent } from './components/edit-product/edit-product.component';
import { HomeComponent } from './components/home/home.component';
import { OtpPageComponent } from './loginRegisterModule/helper/otp-page/otp-page.component';
import { LoginComponent } from './loginRegisterModule/login/login.component';
import { RegisterComponent } from './loginRegisterModule/register/register.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { AdminPComponent } from './rolePages/admin-p/admin-p.component';
import { ClientComponent } from './rolePages/client/client.component';
import { EditProductComponent } from './rolePages/client/edit-product/edit-product.component';
import { ClientprofileComponent } from './rolePages/client/profile/clientprofile/clientprofile.component';
import { OtpVerificationComponent } from './rolePages/user-p-helper/helper/otp-verification/otp-verification.component';
import { UserPAddTocartComponent } from './rolePages/user-p-helper/user-p-add-tocart/user-p-add-tocart.component';
import { UserPAddressPageComponent } from './rolePages/user-p-helper/user-p-address-page/user-p-address-page.component';
import { UserPBillingpageComponent } from './rolePages/user-p-helper/user-p-billingpage/user-p-billingpage.component';
import { UserPContactComponent } from './rolePages/user-p-helper/user-p-contact/user-p-contact.component';
import { UserPHomeComponent } from './rolePages/user-p-helper/user-p-home/user-p-home.component';
import { UserPLoginComponent } from './rolePages/user-p-helper/user-p-login/user-p-login.component';
import { UserPProfileComponent } from './rolePages/user-p-helper/user-p-profile/user-p-profile.component';
import { UserPRegisterComponent } from './rolePages/user-p-helper/user-p-register/user-p-register.component';
import { UserPComponent } from './rolePages/user-p/user-p.component';

export const routes: Routes = [
  // {
  //   path:"",
  //   component:LoginComponent
  // },
  {
    path: "products",
    component: HomeComponent,
    // canActivate:[authGuard] //prevent direct acceess without login
  },
  {
    path: "product/:productId",
    component: ProductDetailComponent,
    // canActivate:[authGuard]
  },
  {
    path: "add-product",
    component: AddProductsComponent,
    // canActivate:[authGuard]
  },

  {
    path: "edit-product/:productId",
    component: EditProductComponent,
    // canActivate:[authGuard]
  },

  {
    path: "verification",
    component: OtpPageComponent
    // canActivate:[authGuard]
  },
  {
    path: "register",
    component: RegisterComponent
  },
  // {
  //   path:"login",
  //   component:LoginComponent
  // },
  {
    //if user otp verification fail then this router will call.
    path: "null",
    component: LoginComponent,
  },
  {
    //if role is user then this router will call.
    path: "",
    component: UserPComponent,
    // canActivate:[authGuard]
    children: [
      {
        path: "user-p-home",
        component: UserPHomeComponent
      },
      {
        path: "user-p-login",
        component: UserPLoginComponent,
        children: [
          {
            path: "otp-verification",
            component: OtpVerificationComponent
          }
        ]
      },
      {
        path: "user-p-register",
        component: UserPRegisterComponent
      },
      {
        path: "user-p-contact",
        component: UserPContactComponent
      },
      {
        path: "user-p-addtocart",
        component: UserPAddTocartComponent,
        children: [
          { path: "user-p-billingpage", component: UserPBillingpageComponent },
          { path: "user-p-addresspage", component: UserPAddressPageComponent }
        ]
      },
      {
        path: "user-p-profile",
        component: UserPProfileComponent
      }

    ]
  },

  {
    //if role is admin then this router will call.
    path: "admin",
    component: AdminPComponent,
    canActivate: [authGuard]
  },
  {
    path: "client",
    component: ClientComponent,
    // canActivate:[authGuard],
    children: [
      {
        path: 'cprofile',
        redirectTo: 'cprofile',
        pathMatch: 'full'
      },
      {
        path: 'add-product',
        component: AddProductsComponent
      },
      {
        path: 'edit-product',
        component: EditProductComponent
      },
      {
        path: "edit-product",
        component: EditProductComponent
        // canActivate:[authGuard]
      },
      {
        path: "cprofile",
        component: ClientprofileComponent
      },
      {
        path: "allProducts",
        component: HomeComponent
      }
    ]
  }

];
