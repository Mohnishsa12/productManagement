import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [MatButtonModule,MatIconModule,MatToolbarModule,MatCardModule,RouterLink],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.scss'
})
export class ProductDetailComponent {
    product!:any;
    //injecting the productservice ref in leftside var.
    productService=inject(ProductService);
    activeRoute=inject(ActivatedRoute);
    ngOnInit(){
      //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
      //Add 'implements OnInit' to the class.
      console.log();
      const productId=this.activeRoute.snapshot.params["productId"];

      this.productService.getProduct(productId).subscribe(result=>{
        this.product=result;
      })
    }
}
