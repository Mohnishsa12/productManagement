export interface orderdetails2 {
  paymentKey: String,
  paymentType: String,
  totalPayment: String,
  addressId: number,
  userId: number
  orderId: String;
}