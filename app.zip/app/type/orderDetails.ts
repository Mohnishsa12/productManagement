export interface orderdetails {
    paymentKey: String,
    paymentType: String,
    totalPayment: String,
    addressId: number,
    userId: number
    // orderdetailsId?: number;
}