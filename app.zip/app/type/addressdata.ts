export interface address {
    id?:number
    name: '',
    number: '',
    pincode: '',
    locality: '',
    address: '',
    city: '',
    state: '',
    landmark: '',
    alternatePhone: '',
    addressType: '',
    userId:''
  };
