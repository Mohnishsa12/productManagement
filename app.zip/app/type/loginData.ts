export interface userData{
    email:String,
    password:String,
    userId:String,
    name:String,
    userRole:String
}