export interface Product{
   brandName: String;
    productCategory: String;
    imageUrl: String;
    currentPrice: String; // Change to number
    standardPrice: String; // Change to number
    discount: String; // Change to number
    productName: String;
    productId: String;
    userId: String;
    // productQuntity:number;
}